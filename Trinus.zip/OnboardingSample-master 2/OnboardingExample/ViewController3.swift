//
//  ViewController3.swift
//  OnboardingExample
//
//  Created by Mattia Cardone on 22/11/2019.
//  Copyright © 2019 Anitaa. All rights reserved.
//

import UIKit

class ViewController3: UIViewController {
/*
    @IBOutlet weak var preview: UIButton!
    @IBOutlet weak var nextF: UIButton!*/
    @IBAction func nextV(_ sender: Any) {
        performSegue(withIdentifier: "connect8", sender: self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
