//
//  ViewController1.swift
//  OnboardingExample
//
//  Created by Mattia Cardone on 21/11/2019.
//  Copyright © 2019 Anitaa. All rights reserved.
//

import UIKit

class ViewController1: UIViewController {

    @IBAction func timerGo(_ sender: UIButton) {
        TimerManager.start(withSeconds: 3)
        TimerManager.timeString = { time, ends in
                if ends == false {
                    self.timerLabel.text = time
                } else {
                    self.performSegue(withIdentifier: "connect6", sender: self)
                }
            }
        
    }
    @IBOutlet weak var timerLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


}
