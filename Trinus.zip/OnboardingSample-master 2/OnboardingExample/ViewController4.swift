//
//  ViewController4.swift
//  OnboardingExample
//
//  Created by Mattia Cardone on 22/11/2019.
//  Copyright © 2019 Wanderlust. All rights reserved.
//

import UIKit

class ViewController4: UIViewController {

    override func viewDidLoad() {
        
    }
  /*
    
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var lab: UILabel!
    var str : String = " "
    
    var image2 : UIImage!
    override func viewDidLoad() {
        super.viewDidLoad()

        image.image = image2
        lab.text = str
 */
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

